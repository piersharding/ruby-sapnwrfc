
# SAPNW is Copyright (c) 2006-2007 Piers Harding.  It is free software, and
# may be redistributed under the terms specified in the README file of
# the Ruby distribution.
#
# Author::   Piers Harding <piers@ompka.net>
# Requires:: Ruby 1.8 or later
#

module SAPNW
  module Parameters
	 
	  # base class for all parameters
	  class Base

		  # they all have:
			#   a name
			#   may or may not have a structure = a type
			#   type may be complex or simple
			#
			#

		end
	end

	module RFC

    # Parameter types
		IMPORT = 1
		EXPORT = 2
		CHANGING = 3
		TABLES = 7

    # basic data types
		CHAR = 0
		DATE = 1
		BCD = 2
		TIME = 3
		BYTE = 4
		TABLE = 5
		NUM = 6
		FLOAT = 7
		INT = 8
		INT2 = 9
		INT1 = 10
		NULL = 14
		STRUCTURE = 17
		DECF16 = 23
		DECF34 = 24
		XMLDATA = 28
		STRING = 29
		XSTRING = 30
		EXCEPTION = 98


    # Base class for all Parameter types
		class Parameter < SAPNW::Parameters::Base
		  attr_reader :name, :type, :direction, :len, :ulen, :decimals, :value

		  # constructor called only from the SAPNW::RFC::Connector#discover process
			#def initialize(funcdesc, name, type, len, ulen, decimals)
			def initialize(*parms)
				parms = parms.first if parms.class == Array and parms.first.class == Hash
			  case parms
				  when Array
					  funcdesc, name, type, len, ulen, decimals = parms
					when Hash
					  raise "Missing parameter :name => #{parms.inspect}\n" unless parms.has_key?(:name)
					  raise "Missing parameter :type => #{parms.inspect}\n" unless parms.has_key?(:type)
						case parms[:type]
						  when SAPNW::RFC::CHAR, SAPNW::RFC::DATE, SAPNW::RFC::BCD, SAPNW::RFC::TIME, SAPNW::RFC::BYTE, SAPNW::RFC::TABLE, SAPNW::RFC::NUM, SAPNW::RFC::FLOAT, SAPNW::RFC::INT, SAPNW::RFC::INT2, SAPNW::RFC::INT1, SAPNW::RFC::NULL, SAPNW::RFC::STRUCTURE, SAPNW::RFC::DECF16, SAPNW::RFC::DECF34, SAPNW::RFC::XMLDATA, SAPNW::RFC::STRING, SAPNW::RFC::XSTRING, SAPNW::RFC::EXCEPTION
							else
							  raise "Invalid SAPNW::RFC* type supplied (#{parms[:type]})\n"
						end
			      funcdesc = nil
			      len = 0
			      ulen = 0
			      decimals = 0
						name = parms[:name]
						type = parms[:type]
						len = parms[:len] if parms.has_key?(:len)
						ulen = parms[:ulen] if parms.has_key?(:ulen)
						decimals = parms[:decimals] if parms.has_key?(:decimals)
					else
					  raise "invalid parameters: #{parms.inspect}\n"
				end
			  @function_descriptor = funcdesc
				@name = name
				@type = type
				@len = len
				@ulen = ulen
				@decimals = decimals
				@value = nil
				#$stderr.print "initilised type(#{name}): #{type}\n"
			end

      # method_missing is used to pass on any method call to a parameter
			# to the underlying native Ruby data type
      def method_missing(methid, *rest, &block)
        meth = methid.id2name
        #$stderr.print "method_missing: #{meth}\n"
        #$stderr.print "parameters: #{@parameters.keys.inspect}\n"
        if block
          @value.send(meth, &block)
        else
          #$stderr.print "Export method_missing - no block: #{meth}\n"
          @value.send(meth, *rest)
        end
      end

      # value setting for parameters - does basic Type checking to preserve
			# sanity for the underlying C extension
			def value=(val=nil)
				#$stderr.print "setting: #{@name} type: #{@type} value: #{val}/#{val.class}\n"
        case @type
				  when SAPNW::RFC::INT, SAPNW::RFC::INT2, SAPNW::RFC::INT1
            unless val.is_a?(Fixnum)
					    raise TypeError, "Must be Fixnum for INT, INT1, and INT2 (#{@name}/#{@type}/#{val.class})\n"
						end
				  when SAPNW::RFC::NUM
            unless val.is_a?(String)
					    raise TypeError, "Must be String for NUMC (#{@name}/#{@type}/#{val.class})\n"
						end
				  when SAPNW::RFC::BCD
            unless val.is_a?(Float) || val.is_a?(Fixnum) || val.is_a?(Bignum)
					    raise TypeError, "Must be FLoat or *NUM for BCD (#{@name}/#{@type}/#{val.class})\n"
						end
						val = val.to_s
				  when SAPNW::RFC::FLOAT
            unless val.is_a?(Float)
					    raise TypeError, "Must be FLoat for FLOAT (#{@name}/#{@type}/#{val.class})\n"
						end
				  when SAPNW::RFC::STRING, SAPNW::RFC::XSTRING
            unless val.is_a?(String)
					    raise TypeError, "Must be String for STRING, and XSTRING (#{@name}/#{@type}/#{val.class})\n"
						end
				  when SAPNW::RFC::BYTE
            unless val.is_a?(String)
					    raise TypeError, "Must be String for BYTE (#{@name}/#{@type}/#{val.class})\n"
						end
				  when SAPNW::RFC::CHAR, SAPNW::RFC::DATE, SAPNW::RFC::TIME
            unless val.is_a?(String)
					    raise TypeError, "Must be String for CHAR, DATE, and TIME (#{@name}/#{@type}/#{val.class})\n"
						end
				  when SAPNW::RFC::TABLE
            unless val.is_a?(Array)
    			    raise TypeError, "Must be Array for table value (#{@name}/#{val.class})\n"
    				end
    				cnt = 0
    			  val.each do |row|
    				  cnt += 1
              unless row.is_a?(Hash)
    			      raise TypeError, "Must be Hash for table row value (#{@name}/#{cnt}/#{row.class})\n"
    				  end
    				end
				  when SAPNW::RFC::STRUCTURE
            unless val.is_a?(Hash)
					    raise TypeError, "Must be a Hash for a Structure Type (#{@name}/#{@type}/#{val.class})\n"
						end
					else # anything - barf
					  raise "unknown SAP data type (#{@name}/#{@type})\n"
				end
				@value = val
				return val
			end

		end

    # RFC Import Parameters
		class Import < SAPNW::RFC::Parameter
		  def initialize(*args)
			  @direction = SAPNW::RFC::IMPORT
				super
			end
		end

    # RFC Export Parameters
		class Export < SAPNW::RFC::Parameter
		  def initialize(*args)
			  @direction = SAPNW::RFC::EXPORT
				super
			end
		end

    # RFC Changing Parameters
		class Changing < SAPNW::RFC::Parameter
		  def initialize(*args)
			  @direction = SAPNW::RFC::CHANGING
				super
			end
		end

    # RFC Table type Parameters
		class Table < SAPNW::RFC::Parameter
		  def initialize(*args)
			  @direction = SAPNW::RFC::TABLES
				super
			end

      # returns the no. of rows currently in the table
      def length
        return @value.length
      end

      # assign an Array, of rows represented by Hashes to the value of
			# the Table parameter.
		  def value=(val=[])
        unless val.is_a?(Array)
			    raise TypeError, "Must be Array for table value (#{@name}/#{val.class})\n"
				end
				cnt = 0
			  val.each do |row|
				  cnt += 1
          unless row.is_a?(Hash)
			      raise TypeError, "Must be Hash for table row value (#{@name}/#{cnt}/#{row.class})\n"
				  end
				end
				@value = val
			end

      # Yields each row of the table to passed Proc
		  def each
			  return nil unless @value
				@value.each do |row|
				  yield row
				end
			end
		end
  end
end
