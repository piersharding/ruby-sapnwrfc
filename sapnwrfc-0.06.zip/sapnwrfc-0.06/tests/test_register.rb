#!/usr/bin/ruby
$KCODE = 'u'
$:.unshift(File.dirname(__FILE__) + '/lib')
$:.unshift(File.dirname(__FILE__) + '/ext/nwsaprfc')
$:.unshift(File.dirname(__FILE__) + '/../lib')
$:.unshift(File.dirname(__FILE__) + '/../ext/nwsaprfc')

require 'sapnwrfc'

TEST_FILE = 'sap.yml'
WAIT = 10

require 'test/unit'
require 'test/unit/assertions'

class SAPFunctionsTest < Test::Unit::TestCase
	def setup
	  #SAP_LOGGER.warn "Current DIR: #{Dir.pwd}\n"
	  if FileTest.exists?(TEST_FILE)
  	  SAPNW::Base.config_location = TEST_FILE
		else
  	  SAPNW::Base.config_location = 'tests/' + TEST_FILE
		end
	  SAPNW::Base.load_config
    SAP_LOGGER.warn "program: #{$0}\n"
	end
	
	def test_BASIC_00010_Test_Deep
		begin 
	    func = SAPNW::RFC::FunctionDescriptor.new("RFC_TEST")
		  func.addParameter(SAPNW::RFC::Export.new(:name => "E1", :len => 10, :type => SAPNW::RFC::CHAR))
		  func.addParameter(SAPNW::RFC::Import.new(:name => "I1", :len => 10, :type => SAPNW::RFC::CHAR))
		  $stderr.print "Function: #{func.inspect}/#{func.parameters.inspect}\n"
	    func.callback = functionCallback = Proc.new do |fc|
		    $stderr.print "got called with #{fc.I1}\n"
			  fc.E1 = fc.I1
	  		return true
		  end
	    assert(server = SAPNW::Base.rfc_register)
	    #assert(SAPNW::Base.installFunction(:sysid => "N4S", :descriptor => func, :callback => functionCallback))
		  # sysid determined from the connection
	    attrib = server.connection_attributes
	    SAP_LOGGER.warn "Connection Attributes: #{attrib.inspect}\n"
	    assert(server.installFunction(:sysid => "N4S", :descriptor => func))
		  exit
	    globalCallback = Proc.new do |server|
	  	  $stderr.print "global got called\n"
	  		return true
	  	end
	  	server.accept(WAIT, globalCallBack)
	  rescue SAPNW::RFC::ConnectionException => e
	    SAP_LOGGER.warn "ConnectionException ERROR: #{e.inspect} - #{e.error.inspect}\n"
	  end
	end
	
	def teardown
	end
end
