
# SAPNW is Copyright (c) 2006-2007 Piers Harding.  It is free software, and
# may be redistributed under the terms specified in the README file of
# the Ruby distribution.
#
# Author::   Piers Harding <piers@ompka.net>
# Requires:: Ruby 1.8 or later
#

module SAPNW

  module Servers

    class << SAPNW::Base

  	  def rfc_register(args = nil)
        parms = {}
  			parms[:trace] = self.config['trace'].to_i        if self.config.key? 'trace'
  			parms[:tpname] = self.config['tpname']           if self.config.key? 'tpname'
  			parms[:gwhost] = self.config['gwhost']           if self.config.key? 'gwhost'
  			parms[:gwserv] = self.config['gwserv']           if self.config.key? 'gwserv'
        SAP_LOGGER.debug("[" + self.name + "] base parameters to be passed are: " + parms.inspect)

        case args
				  when nil
				  when Hash
      			parms[:trace] = args[:trace].to_i        if args.key? :trace
      			parms[:tpname] = args[:tpname]           if args.key? :tpname
      			parms[:gwhost] = args[:gwhost]           if args.key? :gwhost
      			parms[:gwserv] = args[:gwserv]           if args.key? :gwserv
            SAP_LOGGER.debug("[" + self.name + "] with EXTRA parameters to be passed are: " + parms.inspect)
				  else
					  raise "Wrong parameters for Connection - must pass a Hash\n"
				end

        server = SAPNW::RFC::Server.new(parms)
        SAP_LOGGER.debug("completed the server connection (#{server.handle.class}/#{server.handle.object_id}) ...")
	  		return server
	  	end
		end
  end


  module RFC
	  class Server
	    attr_accessor :handle
		  attr_reader   :connection_parameters, :functions

  	  def initialize(args = nil)
  			@connection_parameters = []
        case args
	  		  when nil
	  		  when Hash
	  		    args.each_pair { |key, val|
	  		      @connection_parameters << { 'name' => key.to_s, 'value' => val.to_s }
	  		    }
	  		  else
	  			  raise "Wrong parameters for Server Connection - must pass a Hash\n"
	  		end
        SAP_LOGGER.debug("In #{self.class} initialize: #{@connection_parameters.inspect} ...")
				@functions = {}
				@attributes = nil
		    @handle = SAPNW::RFC::ServerHandle.new(self)
	  	end

  	  def installFunction(args = nil)
			  raise "Must pass a Hash of parameters to installFunction()\n" unless args.class == Hash

				raise "Must pass an instance of SAPNW::RFC::FunctionDescriptor to installFunction()\n" unless args.has_key?(:descriptor) and args[:descriptor].class == SAPNW::RFC::FunctionDescriptor
				func = args[:descriptor]
				raise "Must pass sysid to installFunction()\n" unless args.has_key?(:sysid)
				sysid = args[:sysid]
				res = func.install(sysid)
				@functions[func.name] = func
				return res
	  	end


			def accept(wait=120, callback=nil)
        trap('INT', 'EXIT')
        return self.Accept(wait, callback);
			end
    
	  	def connection_attributes
        SAP_LOGGER.debug("In #{self.class} connection_attributes ...")
        return @attributes = self.handle.connection_attributes()
  		end
   
	    # terminate an established RFC connection.  This will invalidate any currently in-scope
			# FunctionDescriptors associated with this Connection.
  		def close
        SAP_LOGGER.debug("In #{self.class} close ...")
	  	  return nil unless self.handle
        SAP_LOGGER.debug("In #{self.class} handle: #{self.handle} ...")
        res = self.handle.close()
		  	self.handle = nil
				# XXX Should destroy all cached functions and structures and types tied to handle ?
		  	return true
		  end
  	end
	end
end
