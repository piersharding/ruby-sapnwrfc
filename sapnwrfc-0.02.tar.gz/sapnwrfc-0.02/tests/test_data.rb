#!/usr/bin/ruby
$KCODE = 'u'
$stderr.print "program: #{$0}\n"
$:.unshift(File.dirname(__FILE__) + '/lib')
$:.unshift(File.dirname(__FILE__) + '/ext/nwsaprfc')
$:.unshift(File.dirname(__FILE__) + '/../lib')
$:.unshift(File.dirname(__FILE__) + '/../ext/nwsaprfc')

require 'sapnwrfc'

ITER = 5
INNER = 5
TEST_FILE = 'ubuntu.yml'

require 'test/unit'
require 'test/unit/assertions'

class SAPFunctionsTest < Test::Unit::TestCase
	def setup
	  #$stderr.print "Current DIR: #{Dir.pwd}\n"
	  if FileTest.exists?(TEST_FILE)
  	  SAPNW::Base.config_location = TEST_FILE
		else
  	  SAPNW::Base.config_location = 'tests/' + TEST_FILE
		end
	  SAPNW::Base.load_config
	end
	
	def test_BASIC_00010_Test_Data
	  ITER.to_i.times do |iter|
			begin 
	      assert(conn = SAPNW::Base.rfc_connect)
		    attrib = conn.connection_attributes
		    #$stderr.print "Connection Attributes: #{attrib.inspect}\n"
		    fd = conn.discover("Z_TEST_DATA")
		    assert(fd.name == "Z_TEST_DATA")
        f = fd.new_function_call
		    assert(f.name == "Z_TEST_DATA")
        f.CHAR = "German: öäüÖÄÜß"
        f.INT1 = 123
        f.INT2 = 1234
        f.INT4 = 123456
        f.FLOAT = 123456.00
        f.NUMC = '12345'
        f.DATE = '20060709'
        f.TIME = '200607'
        f.BCD = 200607.123
        f.ISTRUCT = { 'ZCHAR' => "German: öäüÖÄÜß", 'ZINT1' => 54, 'ZINT2' => 134, 'ZIT4' => 123456, 'ZFLT' => 123456.00, 'ZNUMC' => '12345', 'ZDATE' => '20060709', 'ZTIME' => '200607', 'ZBCD' => '200607.123' }
        f.DATA = [{ 'ZCHAR' => "German: öäüÖÄÜß", 'ZINT1' => 54, 'ZINT2' => 134, 'ZIT4' => 123456, 'ZFLT' => 123456.00, 'ZNUMC' => '12345', 'ZDATE' => '20060709', 'ZTIME' => '200607', 'ZBCD' => '200607.123' }]
			  #$stderr.print "FunctionCall: #{f.inspect}\n"
			  #$stderr.print "FunctionCall PROGRAM_NAME: #{f.PROGRAM_NAME.value}/#{f.parameters['PROGRAM_NAME'].type}\n"
				begin
				  f.invoke
				rescue SAPNW::RFC::FunctionCallException => e
				  $stderr.print "FunctionCallException: #{e.error.inspect}\n"
				  raise "gone"
				end
				f.RESULT.each do |row|
				  $stderr.print "row: #{row.inspect}\n"
				end
				f.DATA.each do |row|
				  $stderr.print "row: #{row.inspect}\n"
				end

        $stderr.print "ECHAR: #{f.ECHAR}\n"
        $stderr.print "EINT1: #{f.EINT1}\n"
        $stderr.print "EINT2: #{f.EINT2}\n"
        $stderr.print "EINT4: #{f.EINT4}\n"
        $stderr.print "EFLOAT: #{f.EFLOAT}\n"
        $stderr.print "ENUMC: #{f.ENUMC}\n"
        $stderr.print "EDATE: #{f.EDATE}\n"
        $stderr.print "ETIME: #{f.ETIME}\n"
        $stderr.print "EBCD: #{f.EBCD}\n"

        $stderr.print "ESTRUCT: #{f.ESTRUCT.inspect}\n"
		    #assert(conn.close)
			rescue SAPNW::RFC::ConnectionException => e
			  $stderr.print "ConnectionException ERROR: #{e.inspect} - #{e.error.inspect}\n"
			end
			GC.start unless iter % 50
		end
	  GC.start
	end
	
	def test_BASIC_00020_Test_Data
		begin 
		  ITER.times do |cnt|
  	    assert(conn = SAPNW::Base.rfc_connect)
  	    attrib = conn.connection_attributes
  	    #$stderr.print "Connection Attributes: #{attrib.inspect}\n"
  	    fd = conn.discover("Z_TEST_DATA")
  	    assert(fd.name == "Z_TEST_DATA")
	      INNER.to_i.times do |iter|
				  $stderr.print "Start of iteration: #{cnt}/#{iter}\n"
          f = fd.new_function_call
		      assert(f.name == "Z_TEST_DATA")
          f.CHAR = "German: öäüÖÄÜß"
          f.INT1 = 123
          f.INT2 = 1234
          f.INT4 = 123456
          f.FLOAT = 123456.00
          f.NUMC = '12345'
          f.DATE = '20060709'
          f.TIME = '200607'
          f.BCD = 200607.123
          f.ISTRUCT = { 'ZCHAR' => "German: öäüÖÄÜß", 'ZINT1' => 54, 'ZINT2' => 134, 'ZIT4' => 123456, 'ZFLT' => 123456.00, 'ZNUMC' => '12345', 'ZDATE' => '20060709', 'ZTIME' => '200607', 'ZBCD' => '200607.123' }
          f.DATA = [
	  			{ 'ZCHAR' => "German: öäüÖÄÜß", 'ZINT1' => 54, 'ZINT2' => 134, 'ZIT4' => 123456, 'ZFLT' => 123456.00, 'ZNUMC' => '12345', 'ZDATE' => '20060709', 'ZTIME' => '200607', 'ZBCD' => '200607.123' },
	  			{ 'ZCHAR' => "German: öäüÖÄÜß", 'ZINT1' => 54, 'ZINT2' => 134, 'ZIT4' => 123456, 'ZFLT' => 123456.00, 'ZNUMC' => '12345', 'ZDATE' => '20060709', 'ZTIME' => '200607', 'ZBCD' => '200607.123' },
	  			{ 'ZCHAR' => "German: öäüÖÄÜß", 'ZINT1' => 54, 'ZINT2' => 134, 'ZIT4' => 123456, 'ZFLT' => 123456.00, 'ZNUMC' => '12345', 'ZDATE' => '20060709', 'ZTIME' => '200607', 'ZBCD' => '200607.123' },
	  			{ 'ZCHAR' => "German: öäüÖÄÜß", 'ZINT1' => 54, 'ZINT2' => 134, 'ZIT4' => 123456, 'ZFLT' => 123456.00, 'ZNUMC' => '12345', 'ZDATE' => '20060709', 'ZTIME' => '200607', 'ZBCD' => '200607.123' },
	  			{ 'ZCHAR' => "German: öäüÖÄÜß", 'ZINT1' => 54, 'ZINT2' => 134, 'ZIT4' => 123456, 'ZFLT' => 123456.00, 'ZNUMC' => '12345', 'ZDATE' => '20060709', 'ZTIME' => '200607', 'ZBCD' => '200607.123' }
	  			]
	  		  #$stderr.print "FunctionCall: #{f.inspect}\n"
	  		  #$stderr.print "FunctionCall PROGRAM_NAME: #{f.PROGRAM_NAME.value}/#{f.parameters['PROGRAM_NAME'].type}\n"
	  			begin
	  			  f.invoke
	  			rescue SAPNW::RFC::FunctionCallException => e
	  			  $stderr.print "FunctionCallException: #{e.error.inspect}\n"
	  			  raise "gone"
	  			end
	  			f.RESULT.each do |row|
	  			  #$stderr.print "row: #{row.inspect}\n"
	  			end
	  			f.DATA.each do |row|
	  			  #$stderr.print "row: #{row.inspect}\n"
	  			end

          #$stderr.print "ECHAR: #{f.ECHAR}\n"
          #$stderr.print "EINT1: #{f.EINT1}\n"
          #$stderr.print "EINT2: #{f.EINT2}\n"
          #$stderr.print "EINT4: #{f.EINT4}\n"
          #$stderr.print "EFLOAT: #{f.EFLOAT}\n"
          #$stderr.print "ENUMC: #{f.ENUMC}\n"
          #$stderr.print "EDATE: #{f.EDATE}\n"
          #$stderr.print "ETIME: #{f.ETIME}\n"
          #$stderr.print "EBCD: #{f.EBCD}\n"
  
          #$stderr.print "ESTRUCT: #{f.ESTRUCT.inspect}\n"
  			  GC.start unless iter % 10
  	  	end
	  	  assert(conn.close)
	      GC.start
			end
		rescue SAPNW::RFC::ConnectionException => e
		  $stderr.print "ConnectionException ERROR: #{e.inspect} - #{e.error.inspect}\n"
		end
	  GC.start
	end

	def teardown
	end
end
