#!/usr/bin/ruby
$stderr.print "program: #{$0}\n"
$:.unshift(File.dirname(__FILE__) + '/lib')
$:.unshift(File.dirname(__FILE__) + '/ext/nwsaprfc')
$:.unshift(File.dirname(__FILE__) + '/../lib')
$:.unshift(File.dirname(__FILE__) + '/../ext/nwsaprfc')

require 'sapnwrfc'

TEST_FILE = 'sap.yml'

require 'test/unit'
require 'test/unit/assertions'

class SAPConnectTest < Test::Unit::TestCase
	def setup
	  #$stderr.print "Current DIR: #{Dir.pwd}\n"
	  if FileTest.exists?(TEST_FILE)
  	  SAPNW::Base.config_location = TEST_FILE
		else
  	  SAPNW::Base.config_location = 'tests/' + TEST_FILE
		end
	  SAPNW::Base.load_config
	end
	
	def test_BASIC_00010_Basic_Connect
		conn = nil
	  assert(conn = SAPNW::Base.rfc_connect)
		assert(conn.close)
	  assert(conn = SAPNW::Base.rfc_connect(:user => 'developer', :passwd => 'developer'))
		assert(conn.close)
		$stderr.print "end of test 1\n"
	end
	
	def test_BASIC_00020_Connection_Out_Of_Scope
		3.times do
		  conn = nil
	    assert(conn = SAPNW::Base.rfc_connect)
		end
		GC.start
		$stderr.print "end of test 2\n"
	end
	
	def test_BASIC_00030_Volume_Connections
		50.times do
		  conn = nil
	    assert(conn = SAPNW::Base.rfc_connect)
		end
		GC.start
		$stderr.print "end of test 3.1\n"
		50.times do
		  conn = nil
	    assert(conn = SAPNW::Base.rfc_connect)
		end
		GC.start
		$stderr.print "end of test 3.2\n"
		50.times do
		  conn = nil
	    assert(conn = SAPNW::Base.rfc_connect)
		end
		GC.start
		$stderr.print "end of test 3.3\n"
		50.times do
		  conn = nil
	    assert(conn = SAPNW::Base.rfc_connect)
		end
		GC.start
		$stderr.print "end of test 3.4\n"
	end
	
	def test_BASIC_00040_Volume_Connections_With_Close
		99.times do
		  conn = nil
	    assert(conn = SAPNW::Base.rfc_connect)
		  assert(conn.close)
		end
		$stderr.print "end of test 4\n"
		GC.start
		sleep(5)
		GC.start
	end

	def teardown
	end
end
