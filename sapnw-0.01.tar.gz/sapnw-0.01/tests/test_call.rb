#!/usr/bin/ruby
$stderr.print "program: #{$0}\n"
$:.unshift(File.dirname(__FILE__) + '/lib')
$:.unshift(File.dirname(__FILE__) + '/ext/nwsaprfc')
$:.unshift(File.dirname(__FILE__) + '/../lib')
$:.unshift(File.dirname(__FILE__) + '/../ext/nwsaprfc')

require 'sapnw'

ITER = 50
TEST_FILE = 'ubuntu.yml'

require 'test/unit'
require 'test/unit/assertions'

class SAPFunctionsTest < Test::Unit::TestCase
	def setup
	  $stderr.print "Current DIR: #{Dir.pwd}\n"
	  if FileTest.exists?(TEST_FILE)
  	  SAPNW::Base.config_location = TEST_FILE
		else
  	  SAPNW::Base.config_location = 'tests/' + TEST_FILE
		end
	  SAPNW::Base.load_config
	end
	
	def test_BASIC_00010_Program_Read
	  ITER.to_i.times do
			begin 
	      assert(conn = SAPNW::Base.rfc_connect)
		    attrib = conn.connection_attributes
		    #$stderr.print "Connection Attributes: #{attrib.inspect}\n"
		    fd = conn.discover("RPY_PROGRAM_READ")
		    assert(fd.name == "RPY_PROGRAM_READ")
        f = fd.new_function_call
		    assert(fd.parameters.has_key?("PROGRAM_NAME"))
		    assert(f.parameters.has_key?("PROGRAM_NAME"))
		    assert(f.name == "RPY_PROGRAM_READ")
				f.PROGRAM_NAME = 'SAPLGRFC'
			  #$stderr.print "FunctionCall: #{f.inspect}\n"
			  #$stderr.print "FunctionCall PROGRAM_NAME: #{f.PROGRAM_NAME.value}/#{f.parameters['PROGRAM_NAME'].type}\n"
				assert(f.PROGRAM_NAME.value == 'SAPLGRFC')
				begin
				  f.invoke
				rescue SAPNW::RFC::FunctionCallException => e
				  $stderr.print "FunctionCallException: #{e.error.inspect}\n"
				  raise "gone"
				end
				#$stderr.print "#{f.PROG_INF.has_key?('PROG')}\n"
				#$stderr.print "#{f.PROG_INF.value.inspect}\n"
				#f.PROG_INF.each_pair do |k, v|
				#  $stderr.print "#{k} => #{v}\n"
				#end
				#$stderr.print "PROGNAME: #{f.PROG_INF['PROGNAME'].rstrip}#\n"
				assert(f.PROG_INF['PROGNAME'].rstrip == "SAPLGRFC")
				assert(f.SOURCE_EXTENDED.length > 10)
				#f.SOURCE_EXTENDED.each do |row|
				#  $stderr.print "Line: #{row['LINE']}\n"
				#end
		    assert(conn.close)
			rescue SAPNW::RFC::ConnectionException => e
			  $stderr.print "ConnectionException ERROR: #{e.inspect} - #{e.error.inspect}\n"
			end
		end
	  GC.start
	end


	def test_BASIC_00020_Program_Read_Volume
	  assert(conn = SAPNW::Base.rfc_connect)
		attrib = conn.connection_attributes
		fd = conn.discover("RPY_PROGRAM_READ")
		assert(fd.name == "RPY_PROGRAM_READ")
	  ITER.to_i.times do |iter|
      f = fd.new_function_call
		  assert(fd.parameters.has_key?("PROGRAM_NAME"))
		  assert(f.parameters.has_key?("PROGRAM_NAME"))
		  assert(f.name == "RPY_PROGRAM_READ")
			f.PROGRAM_NAME = 'SAPLGRFC'
			assert(f.PROGRAM_NAME.value == 'SAPLGRFC')
			begin
			  f.invoke
			rescue SAPNW::RFC::FunctionCallException => e
			  $stderr.print "FunctionCallException: #{e.error.inspect}\n"
			  raise "gone"
			end
			assert(f.PROG_INF['PROGNAME'].rstrip == "SAPLGRFC")
			assert(f.SOURCE_EXTENDED.length > 10)
	    GC.start unless iter % 50
		end
		assert(conn.close)
	  GC.start
	end


	def test_BASIC_00030_Read_table
	  assert(conn = SAPNW::Base.rfc_connect)
		attrib = conn.connection_attributes
		fd = conn.discover("RFC_READ_TABLE")
		assert(fd.name == "RFC_READ_TABLE")
	  ITER.to_i.times do |iter|
      f = fd.new_function_call
		  assert(fd.parameters.has_key?("QUERY_TABLE"))
		  assert(f.parameters.has_key?("QUERY_TABLE"))
		  assert(f.name == "RFC_READ_TABLE")
			f.QUERY_TABLE = 'T000'
			f.DELIMITER = '|'
			f.ROWCOUNT = 2
			assert(f.QUERY_TABLE.value == 'T000')
			begin
			  f.invoke
			rescue SAPNW::RFC::FunctionCallException => e
			  $stderr.print "FunctionCallException: #{e.error.inspect}\n"
			  raise "gone"
			end
			assert(f.DATA.length > 1)
			#f.DATA.each do |row|
			#  $stderr.print "Line: #{row.inspect}\n"
			#end
	    GC.start unless iter % 50
		end
		assert(conn.close)
	  GC.start
	end

	def teardown
	end
end
