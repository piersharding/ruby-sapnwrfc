#!/usr/bin/ruby
$stderr.print "program: #{$0}\n"
$:.unshift(File.dirname(__FILE__) + '/lib')
$:.unshift(File.dirname(__FILE__) + '/ext/nwsaprfc')
$:.unshift(File.dirname(__FILE__) + '/../lib')
$:.unshift(File.dirname(__FILE__) + '/../ext/nwsaprfc')

require 'sapnw'

TEST_FILE = 'sap.yml'

require 'test/unit'
require 'test/unit/assertions'

class SAPConnectionAttributeTest < Test::Unit::TestCase
	def setup
	  $stderr.print "Current DIR: #{Dir.pwd}\n"
	  if FileTest.exists?(TEST_FILE)
  	  SAPNW::Base.config_location = TEST_FILE
		else
  	  SAPNW::Base.config_location = 'tests/' + TEST_FILE
		end
	  SAPNW::Base.load_config
	end
	
	def test_BASIC_00010_Connection_Attributes
	  assert(conn = SAPNW::Base.rfc_connect)
		attrib = conn.connection_attributes
		$stderr.print "Connection Attributes: #{attrib.inspect}\n"
		assert(attrib.length > 10)
		assert(attrib['sysid'] == 'N4S')
		assert(attrib['progname'].strip == "SAPLSYST")
		assert(attrib['rfc_role'] == 'C')
		assert(conn.close)
	end
	
	def test_BASIC_00010_Connection_Attributes_Volume
	  50.times do
	    assert(conn = SAPNW::Base.rfc_connect)
		  attrib = conn.connection_attributes
		  $stderr.print "Connection Attributes: #{attrib.inspect}\n"
		  assert(attrib.length > 10)
		  assert(attrib['sysid'] == 'N4S')
		  assert(attrib['progname'].strip == "SAPLSYST")
		  assert(attrib['rfc_role'] == 'C')
		  assert(conn.close)
		end
	end

	def teardown
	end
end
