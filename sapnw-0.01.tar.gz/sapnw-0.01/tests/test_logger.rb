$stderr.print "program: #{$0}\n"
$:.unshift(File.dirname(__FILE__) + '/lib')
$:.unshift(File.dirname(__FILE__) + '/ext/nwsaprfc')
$:.unshift(File.dirname(__FILE__) + '/../lib')
$:.unshift(File.dirname(__FILE__) + '/../ext/nwsaprfc')

require 'sapnw'

TEST_FILE = 'test_sap_logger.log'
require 'fileutils'

require 'test/unit'
require 'test/unit/assertions'

class SAPLoggerTest < Test::Unit::TestCase

	
	def setup
	  SAP_LOGGER.set_logdev(TEST_FILE)
	end
	
#  The different ways of connecting to SAP
  def get_log
    log = File.open(TEST_FILE) { |f| f.gets(nil) }
		#$stderr.print log
		return log
  end

  def log_lines
	  lines = get_log.split(/\n/)
		#$stderr.print lines.inspect
		return lines
	end

	def test_BASIC_00010_All_Messages
		assert( SAP_LOGGER.info("an info") )
		assert( SAP_LOGGER.warn("a warning") )
		assert( SAP_LOGGER.error("an error") )
		assert( SAP_LOGGER.fatal("a fatal") )
		assert( SAP_LOGGER.unknown("an unknown") )
		assert( FileTest.exists?(TEST_FILE) )
    assert( log_lines.length == 6 ) # one for each log entry and a header
	end

	def test_BASIC_00020_Above_Warn
	  SAP_LOGGER.level = Logger::WARN
		assert( SAP_LOGGER.info("an info") )
		assert( SAP_LOGGER.warn("a warning") )
		assert( SAP_LOGGER.error("an error") )
		assert( SAP_LOGGER.fatal("a fatal") )
		assert( SAP_LOGGER.unknown("an unknown") )
		assert( FileTest.exists?(TEST_FILE) )
    assert( log_lines.length == 5 ) # one for each log entry >= WARN and a header
	end

	def teardown
	  File.delete(TEST_FILE) if FileTest.exists?(TEST_FILE)
	end
end
