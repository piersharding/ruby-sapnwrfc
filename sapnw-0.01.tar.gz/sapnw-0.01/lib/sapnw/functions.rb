
# SAPNW is Copyright (c) 2006-2007 Piers Harding.  It is free software, and
# may be redistributed under the terms specified in the README file of
# the Ruby distribution.
#
# Author::   Piers Harding <piers@ompka.net>
# Requires:: Ruby 1.8 or later
#

module SAPNW
  module Functions
	 
	end

	module RFC

    # The FunctionDescriptor class doco
		class FunctionDescriptor
		  attr_reader :name, :parameters

      def method_missing(methid, *rest)
        meth = methid.id2name
        if @parameters.has_key?(meth)
			    return @parameters[meth]
			  else
			    raise NoMethodError
			  end
      end

			def new_function_call
			  return create_function_call(SAPNW::RFC::FunctionCall)
			end

			def addParameter(name = nil, direction = 0, type = 0, len = 0, ulen = 0, decimals = 0)

			  #$stderr.print "parm: #{name} direction: #{direction} type: #{type} len: #{len} decimals: #{decimals}\n"
        case direction
				  when SAPNW::RFC::IMPORT
					  if @parameters.has_key?(name) and @parameters[name].direction == SAPNW::RFC::EXPORT
					    p = SAPNW::RFC::Changing.new(self, name, type, len, ulen, decimals)
						else
					    p = SAPNW::RFC::Import.new(self, name, type, len, ulen, decimals)
						end
					when SAPNW::RFC::EXPORT
					  if @parameters.has_key?(name) and @parameters[name].direction == SAPNW::RFC::IMPORT
					    p = SAPNW::RFC::Changing.new(self, name, type, len, ulen, decimals)
						else
					    p = SAPNW::RFC::Export.new(self, name, type, len, ulen, decimals)
						end
					when SAPNW::RFC::CHANGING
					  p = SAPNW::RFC::Changing.new(self, name, type, len, ulen, decimals)
					when SAPNW::RFC::TABLES
					  p = SAPNW::RFC::Table.new(self, name, type, len, ulen, decimals)
					else
					  raise "unknown direction (#{name}): #{direction}\n"
				end
         @parameters[p.name] = p
				 return p
			end

		end

		class FunctionCall
		  attr_reader :name, :function_descriptor, :parameters

			def initialize()
			  @parameters = {}
				@function_descriptor.parameters.each_pair do |k,v|
				  @parameters[k] = v.clone
				end
				@parameters_list = @parameters.values || []
			end

      def method_missing(methid, *rest)
        meth = methid.id2name
			  #$stderr.print "method_missing: #{meth}\n"
				#$stderr.print "parameters: #{@parameters.keys.inspect}\n"
        if @parameters.has_key?(meth)
				  #$stderr.print "return parm obj\n"
			    return @parameters[meth].value
			  elsif mat = /^(.*?)\=$/.match(meth)
				  #$stderr.print "return parm val\n"
          if  @parameters.has_key?(mat[1])
					  return @parameters[mat[1]].value = rest[0]
				  else
					  raise NoMethError
          end
			  else
			    raise NoMethodError
			  end
      end
		end
  end
end
