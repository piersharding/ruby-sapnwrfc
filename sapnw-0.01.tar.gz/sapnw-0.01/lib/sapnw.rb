
  #
  #
  # SAPNW - SAP Netweaver RFC support for Ruby 
	#
	# Welcome to sapnw !
	#
	# sapnw is a RFC based connector to SAP specifically designed for use with the
	# next generation RFC SDK supplied by SAP for NW2004+ .
	#
	#
	# Documentation at: http://www.piersharding.com/download/ruby/sapnw/doc/
	#
	# Project and Download at: http://raa.ruby-lang.org/project/sapnw
	#
	# Please see the examples (tests) distributed with this packages (download source for this) for
	# a comprehensive shake-down on what you can do.
	#
	# Here is a taster using the standard Flight demo BAPIs supplied by SAP:
	#
  #  require 'sapnw'
  #  
  #  TEST_FILE = 'ubuntu.yml'
  # 
	#  # specify the YAML config source and load
  #  SAPNW::Base.config_location = TEST_FILE
  #  SAPNW::Base.load_config
	#
	#  # Connec to SAP
  #  conn = SAPNW::Base.rfc_connect
	#
	#  # Inspect the connection attributes
  #  attrib = conn.connection_attributes
  #  $stderr.print "Connection Attributes: #{attrib.inspect}\n"
	#
	#  # pull in your RFC definitions
  #  fld = conn.discover("BAPI_FLIGHT_GETLIST")
  #  flgd = conn.discover("BAPI_FLIGHT_GETDETAIL")
  #  fd = conn.discover("BAPI_FLBOOKING_CREATEFROMDATA")
	#
	#  # get a new handle for each function call to be invoked
  #  fl = fld.new_function_call
	#
	#  # set the parameters for the call
  #  fl.AIRLINE = "AA "
	#
	#  # ivoke the call
  #  fl.invoke
	#
	#  # interogate the results
  #  fl.FLIGHT_LIST.each do |row|
  #  	  $stderr.print "row: #{row.inspect}\n"
	#
	#  	  # for each flight now do another RFC call to get the details
  #     flg = flgd.new_function_call
  #  	  flg.AIRLINEID = row['AIRLINEID']
  #  	  flg.CONNECTIONID = row['CONNECTID']
  #  	  flg.FLIGHTDATE = row['FLIGHTDATE']
  #  	  flg.invoke
  #  	  $stderr.print "\tflight data: #{flg.FLIGHT_DATA.inspect}\n"
  #  	  $stderr.print "\tadditional info: #{flg.ADDITIONAL_INFO.inspect}\n"
  #  	  $stderr.print "\tavailability: #{flg.AVAILIBILITY.inspect}\n"
  #  end
	#
	#  # create a new booking 
  #  fd.name == "BAPI_FLBOOKING_CREATEFROMDATA"
  #  f = fd.new_function_call
  #  f.BOOKING_DATA = { 'AIRLINEID' => "AA ", 'CONNECTID' => "0001", 'FLIGHTDATE' => "20070130", 'CLASS' => "F", 'CUSTOMERID' => "00000001", 'AGENCYNUM' => '00000093' }
	#
	#  # trap Function Call exceptions
  #  begin
  #    f.invoke
  #  rescue SAPNW::RFC::FunctionCallException => e
  #    $stderr.print "FunctionCallException: #{e.error.inspect}\n"
  #    raise "gone"
  #  end
  #  f.RETURN.each do |row|
  #    $stderr.print "row: #{row.inspect}\n"
  #  end
	#
	#  # use the standard COMMIT BAPI to commit the update
  #  cd = conn.discover("BAPI_TRANSACTION_COMMIT")
  #  c = cd.new_function_call
  #  c.WAIT = "X"
  #  c.invoke
	#
	#  # close the RFC connection and destroy associated resources
  #  conn.close
	#  
	#  
	#  
	#  
	# Thanks to:
	#   Craig Cmehil   - SAP, and SDN
	#   Ulrich Schmidt - SAP
	# For their help in making this possible.
	#  
	#  
	#  
	#  
	#  
  # SAPNW is Copyright (c) 2006-2007 Piers Harding.  It is free software, and
  # may be redistributed under the terms specified in the README file of
  # the Ruby distribution.
  #
  # Author::   Piers Harding <piers@ompka.net>
  # Requires:: Ruby 1.8.0 or later
  #


$:.unshift(File.dirname(__FILE__)) unless
  $:.include?(File.dirname(__FILE__)) || $:.include?(File.expand_path(File.dirname(__FILE__)))

require 'yaml'
require 'fileutils'
require 'logger'

SAP_LOGGER = Logger.new(STDERR)
SAP_LOGGER.datetime_format = "%Y-%m-%d %H:%M:%S"

require 'sapnw/base'

# C extension
unless require 'nwsaprfc'
 raise "cannot load C EXT nwsaprfc.so"
end

require 'sapnw/config'
require 'sapnw/connection'
require 'sapnw/functions'
require 'sapnw/parameters'

SAPNW::Base.class_eval do
  include SAPNW::Config
  include SAPNW::Connections
  include SAPNW::Functions
  include SAPNW::Parameters
end

