$stderr.print "program: #{$0}\n"
$:.unshift(File.dirname(__FILE__) + '/lib')
$:.unshift(File.dirname(__FILE__) + '/ext/nwsaprfc')
$:.unshift(File.dirname(__FILE__) + '/../lib')
$:.unshift(File.dirname(__FILE__) + '/../ext/nwsaprfc')

require 'sapnwrfc'

TEST_FILE = 'alternate_sap.yml'

require 'test/unit'
require 'test/unit/assertions'

class SAPConfigTest < Test::Unit::TestCase

	
	def setup
	  SAPNW::Base.load_config
	end
	
	def test_BASIC_00010_Config_Loaded
		assert( SAPNW::Base.config.length == 7 )
		assert( SAPNW::Base.config['ashost'] == 'ubuntu.local.net' )
		assert( SAPNW::Base.config['sysnr'] == '01' )
		assert( SAPNW::Base.config['client'] == '001' )
		assert( SAPNW::Base.config['user'] == 'developer' )
		assert( SAPNW::Base.config['trace'] == 2 )
	end
	
	def test_BASIC_00020_Alternate_Config
	  SAPNW::Base.config_location = TEST_FILE
		assert( config = SAPNW::Base.load_config )
		assert( config.length == 7 )
		assert( SAPNW::Base.config.length == 7 )
		assert( SAPNW::Base.config['ashost'] == 'ubuntu.local.net' )
		assert( SAPNW::Base.config['sysnr'] == '00' )
		assert( SAPNW::Base.config['client'] == '000' )
		assert( SAPNW::Base.config['user'] == 'developer' )
		assert( SAPNW::Base.config['trace'] == 1 )
	end

	def teardown
	end
end
