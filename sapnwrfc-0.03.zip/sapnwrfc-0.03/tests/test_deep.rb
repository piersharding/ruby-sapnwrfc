#!/usr/bin/ruby
$KCODE = 'u'
$stderr.print "program: #{$0}\n"
$:.unshift(File.dirname(__FILE__) + '/lib')
$:.unshift(File.dirname(__FILE__) + '/ext/nwsaprfc')
$:.unshift(File.dirname(__FILE__) + '/../lib')
$:.unshift(File.dirname(__FILE__) + '/../ext/nwsaprfc')

require 'sapnwrfc'

TEST_FILE = 'ubuntu.yml'

ITER = 50

require 'test/unit'
require 'test/unit/assertions'

class SAPFunctionsTest < Test::Unit::TestCase
	def setup
	  #$stderr.print "Current DIR: #{Dir.pwd}\n"
	  if FileTest.exists?(TEST_FILE)
  	  SAPNW::Base.config_location = TEST_FILE
		else
  	  SAPNW::Base.config_location = 'tests/' + TEST_FILE
		end
	  SAPNW::Base.load_config
	end
	
	def test_BASIC_00010_Test_Deep
		begin 
		  ITER.times do |iter|
	      assert(conn = SAPNW::Base.rfc_connect)
	      attrib = conn.connection_attributes
	      $stderr.print "Connection Attributes: #{attrib.inspect}\n"
		    fds = conn.discover("STFC_DEEP_STRUCTURE")
	      $stderr.print "Parameters: #{fds.parameters.keys.inspect}\n"
        fs = fds.new_function_call
			  fs.IMPORTSTRUCT = { 'I' => 123, 'C' => 'AbCdEf', 'STR' =>  'The quick brown fox ...', 'XSTR' => ["deadbeef"].pack("H*") }
		    fs.invoke
	      $stderr.print "RESPTEXT: #{fs.RESPTEXT.inspect}\n"
	      $stderr.print "ECHOSTRUCT: #{fs.ECHOSTRUCT.inspect}\n"
			  assert(fs.ECHOSTRUCT['I'] == 123)
			  assert(fs.ECHOSTRUCT['C'].rstrip == 'AbCdEf')
			  assert(fs.ECHOSTRUCT['STR'] == 'The quick brown fox ...')
			  assert(fs.ECHOSTRUCT['XSTR'].unpack("H*").first == 'deadbeef')
		    fdt = conn.discover("STFC_DEEP_TABLE")
	      $stderr.print "Parameters: #{fdt.parameters.keys.inspect}\n"
        ft = fdt.new_function_call
			  ft.IMPORT_TAB = [{ 'I' => 123, 'C' => 'AbCdEf', 'STR' =>  'The quick brown fox ...', 'XSTR' => ["deadbeef"].pack("H*") }]
		    ft.invoke
	      $stderr.print "RESPTEXT: #{ft.RESPTEXT.inspect}\n"
	      $stderr.print "EXPORT_TAB: #{ft.EXPORT_TAB.inspect}\n"
			  assert(ft.EXPORT_TAB[0]['I'] == 123)
			  assert(ft.EXPORT_TAB[0]['C'].rstrip == "AbCdEf")
			  assert(ft.EXPORT_TAB[0]['STR'] == 'The quick brown fox ...')
	      ft.EXPORT_TAB.each do |row|
	        $stderr.print "XSTR: #{row['XSTR'].unpack("H*")}#\n"
			    assert(row['XSTR'].unpack("H*").first == 'deadbeef')
			  end
		    assert(conn.close)
			  GC.start unless iter % 50
			end
		rescue SAPNW::RFC::FunctionCallException => e
		  $stderr.print "FunctionCallException: #{e.error.inspect}\n"
		  raise "gone"
		end
	end
	
	def test_BASIC_00020_Test_Deep
		begin 
	      assert(conn = SAPNW::Base.rfc_connect)
	      attrib = conn.connection_attributes
	      $stderr.print "Connection Attributes: #{attrib.inspect}\n"
		    fds = conn.discover("STFC_DEEP_STRUCTURE")
	      $stderr.print "Parameters: #{fds.parameters.keys.inspect}\n"
		    fdt = conn.discover("STFC_DEEP_TABLE")
	      $stderr.print "Parameters: #{fdt.parameters.keys.inspect}\n"
		    ITER.times do |iter|
			    GC.start unless iter % 50
          fs = fds.new_function_call
			    fs.IMPORTSTRUCT = { 'I' => 123, 'C' => 'AbCdEf', 'STR' =>  'The quick brown fox ...', 'XSTR' => ["deadbeef"].pack("H*") }
		      fs.invoke
	        $stderr.print "RESPTEXT: #{fs.RESPTEXT.inspect}\n"
	        $stderr.print "ECHOSTRUCT: #{fs.ECHOSTRUCT.inspect}\n"
			    assert(fs.ECHOSTRUCT['I'] == 123)
			    assert(fs.ECHOSTRUCT['C'].rstrip == 'AbCdEf')
			    assert(fs.ECHOSTRUCT['STR'] == 'The quick brown fox ...')
			    assert(fs.ECHOSTRUCT['XSTR'].unpack("H*").first == 'deadbeef')
          ft = fdt.new_function_call
			    ft.IMPORT_TAB = [{ 'I' => 123, 'C' => 'AbCdEf', 'STR' =>  'The quick brown fox ...', 'XSTR' => ["deadbeef"].pack("H*") }]
		      ft.invoke
	        $stderr.print "RESPTEXT: #{ft.RESPTEXT.inspect}\n"
	        $stderr.print "EXPORT_TAB: #{ft.EXPORT_TAB.inspect}\n"
			    assert(ft.EXPORT_TAB[0]['I'] == 123)
			    assert(ft.EXPORT_TAB[0]['C'].rstrip == "AbCdEf")
			    assert(ft.EXPORT_TAB[0]['STR'] == 'The quick brown fox ...')
	        ft.EXPORT_TAB.each do |row|
	          $stderr.print "XSTR: #{row['XSTR'].unpack("H*")}#\n"
			      assert(row['XSTR'].unpack("H*").first == 'deadbeef')
			    end
			  end
		    assert(conn.close)
		rescue SAPNW::RFC::FunctionCallException => e
		  $stderr.print "FunctionCallException: #{e.error.inspect}\n"
		  raise "gone"
		end
	end

	def teardown
	end
end
